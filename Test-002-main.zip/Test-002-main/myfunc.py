# ฟังก์ชันบวก A + B
def add_numbers(a, b):
    return a + b

# ตัวอย่างการใช้งาน
A = int(input("กรอกค่า A: "))
B = int(input("กรอกค่า B: "))

ผลลัพธ์ = add_numbers(A, B)
print("ผลลัพธ์ของ A + B =", ผลลัพธ์)
